#include <boot/memory/physical.h>
#include <boot/memory/virtual.h>
#include <boot/log/logf.h>

extern void kernel_main();

void __attribute__((section("bootstrap"))) bootstrap_main(void* multiboot_struct) {
    enable_cursor();
    bootstrap_clrscr();
    bootstrap_logf("Alexos starting...\n");
    init_pmm(multiboot_struct);
    init_vmm(kernel_main);
}
