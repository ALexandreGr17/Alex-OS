#ifndef BOOTSTRAP_VMM_H
#define BOOTSTRAP_VMM_H

void init_vmm(void (*entry)());

#endif // !BOOTSTRAP_VMM_H


