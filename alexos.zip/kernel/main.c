#include "logs/log.h"
#include <stdint.h>
#include <memory/memory.h>
#include <memory/physical/physical_memory_manager.h>



void kernel_main(void* multiboot_struct) {
    clrscr();
    puts("test\n\t");
    logf("Hello %s%c %i %x\n", "world", '!', 10, 10);

    while(1);
}
